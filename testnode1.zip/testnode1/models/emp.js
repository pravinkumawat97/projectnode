const mongoose=require('mongoose')

const empSchema=mongoose.Schema({
    name:String,
    dept:String,
    salary:Number,
    image:String
 })

module.exports=mongoose.model('emp',empSchema)