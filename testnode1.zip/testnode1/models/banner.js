const mongoose=require('mongoose')

const bannerSchema=mongoose.Schema({
    name:String,
    dept:String,
    image:String,
    date:{type:Date,default:new Date()}
 })

module.exports=mongoose.model('banner',bannerSchema)