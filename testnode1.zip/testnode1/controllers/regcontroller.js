const Reg=require('../models/reg')

exports.loginpage=(req,res)=>{
    res.render('login.ejs')
}
exports.singuppage=(req,res)=>{
    res.render('reg.ejs')
}
exports.singupinsert= async (req,res)=>{
   const {us,pass}=req.body
   const usercheck=await Reg.findOne({name:us})
   if(usercheck===null){
    const record= Reg({name:us,password:pass})
    record.save()
   }else{
    res.send('username is already teken')
   } 
 // console.log(usercheck)
  //console.log(record) 
}
exports.logincheck= async (req,res)=>{
    const {uss,pass}=req.body
  const record=await Reg.findOne({name:uss})
    // console.log(record)
    if(record!==null){
        if(record.password==pass){
            req.session.isAuth=true
            req.session.loginCheck=uss            
        res.redirect('/empdatashow')
        }else{
            res.send('wrong password')
        }
    }else{
        res.send('wrong username')
    }
}
exports.logout=(req,res)=>{
     req.session.destroy()
     res.redirect('/login')
}