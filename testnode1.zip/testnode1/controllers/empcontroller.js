const Emp=require('../models/emp')

exports.emppage=(req,res)=>{
    res.render('empform.ejs')
}
exports.empinsert=(req,res)=>{
    const filename=req.file.filename
    const {ename,edept,esalary}=req.body
   const record=Emp({name:ename,dept:edept,salary:esalary,image:filename})
   record.save()
   //console.log(record)
   res.redirect('/empdatashow')
}
exports.empdatashow=async (req,res)=>{
    const record=await Emp.find()
    //console.log(record)
  const name=req.session.loginCheck
     res.render('empdatashow.ejs',{record,name})
 }
 exports.empdelete=async (req,res)=>{
    const id=req.params.vk
   await Emp.findByIdAndDelete(id)
   res.redirect('/empdatashow')
}
exports.empupdate=async (req,res)=>{
   // const id=req.params.kk
   const record=await Emp.findById(req.params.kk)
  // console.log(record)
   res.render('empupdateform.ejs',{record})
}
exports.empupdateform=async (req,res)=>{
    const filename=req.file.filename
    const id=req.params.ck
    const {uname,udept,usalary}=req.body
   await Emp.findByIdAndUpdate(id,{name:uname,dept:udept,salary:usalary,image:filename})
    res.redirect('/empdatashow')
}