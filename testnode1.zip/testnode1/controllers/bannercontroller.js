const Banner=require('../models/banner')

exports.bannerform=(req,res)=>{
    res.render('bannerform.ejs')
}
exports.bannerinsert=(req,res)=>{
    const filename=req.file.filename
     const {ename,edept}=req.body
    const record=Banner({name:ename,dept:edept,image:filename})
    record.save()
    res.redirect('/bannerdatashow')
    //console.log(record)
}
exports.bannerdatashow=async (req,res)=>{
   const record= await Banner.find()
  // console.log(record)
    res.render('bannerdatashow.ejs',{record})
}
exports.bannerdelete= async (req,res)=>{
    const id=req.params.id
   const record=await Banner.findByIdAndDelete(id)
    res.redirect('/bannerdatashow')
}
exports.bannerupdateform= async (req,res)=>{
    const id=req.params.id
    const record =await Banner.findById(id)
    res.render('bannerupdate.ejs',{record})
}
exports.bannerupdate= async (req,res)=>{
    const id=req.params.id
    const {uname,udept}=req.body
   await Banner.findByIdAndUpdate(id,{name:uname,dept:udept})
    res.redirect('/bannerdatashow')
}