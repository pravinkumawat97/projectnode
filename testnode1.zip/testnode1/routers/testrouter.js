const router=require('express').Router()
const Emp=require('../models/emp')
const multer=require('multer')
const nodemailer=require('nodemailer')
const empc=require('../controllers/empcontroller')
const regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')

const storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
 })

const upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})

router.get('/',sessioncheck,(req,res)=>{
    res.render('index.ejs')
   // res.send('welcom to home page')
})
router.get('/empform',empc.emppage)
router.post('/empform',upload.single('img'),empc.empinsert)
router.get('/empdatashow',sessioncheck, empc.empdatashow)
router.get('/empdelete/:vk',empc.empdelete)
router.get('/empupdate/:kk',empc.empupdate)
router.post('/empupdate/:ck',upload.single('imag'),empc.empupdateform)

router.get('/login',regc.loginpage)
router.get('/reg',regc.singuppage)
router.post('/reg',regc.singupinsert)
router.post('/login',regc.logincheck)
router.get('/logout',regc.logout)

router.get('/bannerform',bannerc.bannerform)
router.post('/bannerform',upload.single('img'),bannerc.bannerinsert)
router.get('/bannerdatashow',bannerc.bannerdatashow)
router.get('/bannerdelete/:id',bannerc.bannerdelete)
router.get('/bannerupdate/:id',bannerc.bannerupdateform)
router.post('/bannerupdate/:id',bannerc.bannerupdate)

function sessioncheck(req,res,next){
     if(req.session.isAuth){
        next()
     }else{
        res.redirect('/login')
     }
}
 
router.get('/emailform',(req,res)=>{
    res.render('emailform.ejs')
})
router.post('/emailform',upload.single('attachment'),async (req,res)=>{
    console.log(req.file)
      const {emailto,emailfrom,sub,body,attachment}=req.body
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user: 'kumawatpravin4566@gmail.com',
          pass: 'sedtlfmrzvehyeuo'
        }
      });
      console.log('connect to gmail smtp server')

      const info = await transporter.sendMail({
        from: emailfrom, // sender address
        to: emailto, // list of receivers
        subject: sub, // Subject line
        text: body, // plain text body
       // html: "<b>Hello world?</b>", // html body
       attachments:attachment,
      });
    console.log('email sent')
    
})

 module.exports=router