const http=require('http')
const fs=require('fs')
const style=fs.readFileSync('./style.css')
const home=fs.readFileSync('./home.html')


const server=http.createServer((req,res)=>{
  if(req.url==='/'){
    res.write(home)
    res.end()
  }
  else if(req.url==='/style.css'){
    res.write(style)
    res.end()
  }
  else{
    res.end('404 file not found')
  }
})

 server.listen(5000)